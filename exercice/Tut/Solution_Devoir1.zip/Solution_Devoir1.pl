%Devoir CSI2510

%Question 1, requetes en commentaire

city(ottawa,ontario).
city(toronto,ontario).
city(kingston,ontario).
city(gatineau,quebec).
city(montreal,quebec).
company(shopify,ottawa).
company(rossvideo,ottawa).
company(dium,gatineau).
company(uber,toronto).
company(deepmind,montreal).
company(google,toronto).
person(annie,gatineau).
person(paul,gatineau).
person(suzy,gatineau).
person(robert,gatineau).
person(tom,ottawa).
person(tim,kingston).
person(joe,montreal).
person(jane,ottawa).
person(marie,ottawa).
person(jack,toronto).
person(simon,toronto).
employee(annie,dium).
employee(tom,shopify).
employee(jane,shopify).
employee(marie,shopify).
employee(joe,deepmind).
employee(jack,google).
employee(simon,google).
employee(suzy,shopify).
employee(paul,rossvideo).
employee(marie,rossvideo).
employee(simon,uber).

% a)
% findall(Name, (person(Name, Ville), employee(Name,Company), company(Company,OtherCity), Ville\=OtherCity), List).
q1(List):- findall(Name, (person(Name, Ville), employee(Name,Company), company(Company,OtherCity), Ville\=OtherCity), List).

% b)
% findall(C, (city(V,ontario), company(C,V)), L).
q2(L):- findall(C, (city(V,ontario), company(C,V)), L).

% c)
% findall(N,( person(N,_), not(employee(N,_))),L).
q3(L):- findall(N,( person(N,_), not(employee(N,_))),L).

% d)
% findall(Name, (person(Name, _), employee(Name,Company), company(Company,ottawa)), L).
q4(L):- findall(Name, (person(Name, _), employee(Name,Company), company(Company,ottawa)), L).

% e) Il y a deux fois marie car elle a deux travails à ottawa.
% setof(Name, Company^X^(person(Name, X), employee(Name,Company), company(Company,City), City=ottawa), L).
q5(L):- setof(Name, Company^X^(person(Name, X), employee(Name,Company), company(Company,City), City=ottawa), L).


%Question 2 : Voir le document

%Question 3
distance(La1, Lo1, La2, Lo2, D) :- 
    SinLat is (sin((La1 - La2)/2)*sin((La1 - La2)/2)), 
    SinLong is (sin((Lo1 - Lo2)/2)*(sin((Lo1 - Lo2)/2))), 
    D is 6371*(2 * asin(sqrt(SinLat + (cos(La1)*cos(La2)*SinLong)))).

%Question 4
absDiff([],[],[]).
absDiff([H1|T1],[H2|T2],[Diff|L]):- absDiff(T1,T2, L), Diff is abs(H1-H2).

absDiffA([],[],[]).
absDiffA([H|T],[],[Diff|L]):- absDiffA(T,[],L), Diff is H.
absDiffA([],[H|T],[Diff|L]):- absDiffA(T,[],L), Diff is H.
absDiffA([H1|T1],[H2|T2],[Diff|L]):- absDiffA(T1,T2, L), Diff is abs(H1-H2).

absDiffB([],_,[]).
absDiffB(_,[],[]).
absDiffB([H1|T1],[H2|T2],[Diff|L]):- absDiffB(T1,T2, L), Diff is abs(H1-H2).

%Question 5 : 
flower(rose,red).
flower(marigold,yellow).
flower(tulip,red).
flower(daffodil,yellow).
flower(rose,yellow).
flower(maigold,red).
flower(rose,white).
flower(cornflower,purple).

bouquet(A,B,C):- flower(X,red), flower(Y,red), X\=Y,!, 
    flower(A,red), flower(B,red), flower(C,_), A\=B, A\=C, B\=C.
bouquet(X,Y,Z):- flower(X,C1), flower(Y,C2), flower(Z,C3), C1\=C2, C1\=C3, C2\=C3, X\=Y, X\=Z, Y\=Z.