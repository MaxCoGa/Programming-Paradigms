package main

import (
	"fmt"
	"time"
)

func main() {
	ch := make(chan int)
	for i := 0; i < 10; i++ {
		go func(j int) {
			ch <- j
		}(i)
	}
	go func(c chan int) {
		for {
			if num, ok := <-c; !ok {
				break
			} else {
				fmt.Printf("%d\n", num)
			}
		}
	}(ch)
	time.Sleep(2 * time.Second)
	close(ch)
}
